/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidaycelebrations;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author 6306841
 */
public class HolidayCelebrations {

    /**
     * @param args the command line arguments
     */
    
    // The driver class where we work on the Array list and the import of the file
    // we are going to use.
    
   
    public static void main(String[] args) throws IOException {
        ArrayList<Celebratable> myFamilyTraditions = createTraditions();
        celebrateHolidays(myFamilyTraditions);
        
        
    }
    
    public static ArrayList<Celebratable> createTraditions() throws IOException
    {
       //Create an ArrayList that will hold objects of grandParents, parents, and children
        
        // Array list created called myFam that will use the holiday.txt file
        ArrayList <Celebratable> myFam =  new ArrayList <Celebratable> ();
        
        File aFile = new File("holidays.txt");
        Scanner inFile = new Scanner(aFile);
        
        // These are reference variables. They are refrencing an object.
        GrandparentsTradition aGrandParent;
        ParentsTradition aParent;
        ChildrenTradition aChild;
        
        String typeRecord;
        String record;
        String [] recordArray;
        // This is a reference variable, array does not exist yet
        
        String holidayName;
        String holidaySeason;
        String timeOfDayCelebration;      
        String mainDishName;    
        int numberOfSideDishes;
        String locationOfGathering;      
        double costOfMeal;
        String mealSource; 
        
        int numberInvited = 0;
        String traditionalDessert = "";
        String traditionalDrink = "";
        double costPerDessert = 0;
        double costPerDrink = 0;
        
        String holidayGame = "";
        String holidayStorybook = "";
        String holidayMovie = "";
        double costOfMovie = 0;
        
        
        // in order to read the file, we need to create a loop.
        while (inFile.hasNext())
        {
            //read the file and create the appropriate object (GrandparentsTradition, ParentsTradition, and ChildrenTradition)
            record = inFile.nextLine();
            recordArray = record.split(" ");
            
            if ( recordArray[0].equalsIgnoreCase("g"))
                
                // with each a"Person", we add new objects to the array as they elongate, so GP has 8, P has 13 and C has 17.
                // and each recordArray can be different as some are double and ints.
            {
               aGrandParent = new GrandparentsTradition (recordArray[1], recordArray[2],recordArray[3],recordArray[4],Integer.parseInt(recordArray[5]),recordArray[6],Double.parseDouble(recordArray[7]),recordArray[8]);
               myFam.add(aGrandParent);
            }
            else if (recordArray[0].equalsIgnoreCase("p")) 
            {
                aParent = new ParentsTradition (recordArray[1], recordArray[2],recordArray[3],recordArray[4],Integer.parseInt(recordArray[5]),recordArray[6],Double.parseDouble(recordArray[7]),recordArray[8], Integer.parseInt(recordArray[9]), recordArray[10], recordArray[11], Double.parseDouble(recordArray[12]), Double.parseDouble(recordArray[13]));
                // You have to add the other recordArray, because it is long in the "P". The holiday text.
                myFam.add (aParent);
            }
            else if (recordArray[0].equals("c"))
            {
                aChild = new ChildrenTradition (recordArray[1], recordArray[2],recordArray[3],recordArray[4],Integer.parseInt(recordArray[5]),recordArray[6],Double.parseDouble(recordArray[7]),recordArray[8], Integer.parseInt(recordArray[9]), recordArray[10], recordArray[11], Double.parseDouble(recordArray[12]), Double.parseDouble(recordArray[13]), recordArray[14], recordArray[15], recordArray[16], Double.parseDouble(recordArray[17]));;
                myFam.add (aChild);
         
            }
            //Remember to use an if-statement to check the first letter of the record and determine what object to create
            //instantiate the corresponding object:  aGrandParent, aParent, or aChild
            //add the object created to the arrayList
            
        }
        
        inFile.close();
        
       //return the arrayList created and populated.
       //return myFam
    return myFam;
    
}

    public static void celebrateHolidays(ArrayList<Celebratable> myFamilyTraditions)
    {
         //code the celebrateHolidays method to iterate through the arrayList of objects
        // A for loop was made as we want to itterate through every line of text.
        // calls the "celebrate" and "tabulate" polymorphic methods. 
        
        for (int i = 0; i < myFamilyTraditions.size(); i++) {
        
            
            System.out.println(myFamilyTraditions.get(i).celebrate());
            System.out.println(myFamilyTraditions.get(i).tabulateCosts());

    }
        
        
    }
    
    
   
    
}

