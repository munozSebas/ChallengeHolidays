/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidaycelebrations;

     // @author: Sebastian Munoz (6306
import java.text.DecimalFormat;


     //2/2/22

public class ChildrenTradition extends ParentsTradition {
   
    //1. Define 4 additional private attributes that the parents have (don't re-define from the superclass)
 
    private String holidayGame;
    private String holidayStoryBook;
    private String holidayMovie;
    private double costOfMovie;
    
    //2. Define the Childrens constructor that receives 17 parameters,  and invokes the Parents constructor first,
    // you add all the 17 constructors, the ones from GP, P and add the new ones here to make up the 17 parameters.
    // constructor

    public ChildrenTradition(String holidayName, String holidaySeason, String timeOfDayCelebration, String mainDishName, int numberOfSideDishes, String locationOfGathering, double costOfMeal, String mealSource, int numberInvited, String traditionalDessert, String traditionalDrink, double costPerDessert, double costPerDrink, String holidayGame, String holidayStoryBook, String holidayMovie, double costOfMovie) {
       
        
        // The super are referencing, the other constructors, but only the ones that are related, not any new ones.
        super (holidayName, holidaySeason, timeOfDayCelebration, mainDishName, numberOfSideDishes, locationOfGathering, costOfMeal, mealSource, numberInvited, traditionalDessert,traditionalDrink, costPerDessert,  costPerDrink);

        this.holidayGame = holidayGame;
        this.holidayStoryBook = holidayStoryBook;
        this.holidayMovie = holidayMovie;
        this.costOfMovie = costOfMovie;
    }
        
    //3.  and then initializes the rest of the values in the Childrens' attributes.

    //4. Define a getter and a setter for each of the 4 attributes in the Children class

    public String getholidayGame() {
        return holidayGame;
    }

    public void setholidayGame(String holidayGame) {
        this.holidayGame = holidayGame;
    }

    public String getholidayStoryBook() {
        return holidayStoryBook;
    }

    public void setholidayStoryBook(String holidayStoryBook) {
        this.holidayStoryBook = holidayStoryBook;
    }

    public String getholidayMovie() {
        return holidayMovie;
    }

    public void setholidayMovie (String holidayMovie) {
        this.holidayMovie = holidayMovie;
    }

    public double getcostOfMovie() {
        return costOfMovie;
    }

    public void setcostOfMovie(double costOfMovie) {
        this.costOfMovie = costOfMovie;
    }

    
    //5. Define the toString() method  invoking 
//   the toString() of the super class PLUS it 
//     concatenates its own toString logic:
//
//  AND, before and after our meal we like to play _____.
//  We also like watching holiday movies like _______ which usually cost about _____
//  At bedtime, we like to read holiday stories like _________. 

    
    public String toString () {
    
        return super.toString() + "AND, before and afer our meal we like to play"+ holidayGame+ "." +
        "\nWe also like watching holiday movies like "+ holidayMovie +" which usually cost about $"+ costOfMovie + "." +
        "\nAt bedtime, we like to read holiday stories like "+ holidayStoryBook + "." ;
        
       
    }
    
    //6. Define the POLYMORPHIC celebrate method that concatenates "We children like to celebrate the holidays like " to the toString

    @Override
    public String celebrate () {
      
        return "\nWe children like to celebrate the holiday like " + toString();
        
        
    }
    
    //7. Define the POLYMORPHIC tabulateCosts method that concatenates "plus the cost of a movie: ____"

        @Override
        public String tabulateCosts () {
                DecimalFormat df = new DecimalFormat("##0.00");
                return super.tabulateCosts() + " plus the cost of a movie: $"+ df.format(costOfMovie);
        
       
    }
    
    
    
}
    
    



    
// BHG bankers healths group INTERNSHIP OPP

