/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidaycelebrations;

import java.text.DecimalFormat;


// @author: Sebastian Munoz (6306841)
// 2/2/22
// 


//Code the ParentsTradition  class here:
//1. Define 5 additional private attributes that the parents have (don't re-define from the superclass)

public class ParentsTradition extends GrandparentsTradition {

   
private int numberInvited;
private String traditionalDessert;
private String traditionalDrink;
private double costPerDessert;
private double costPerDrink;

//2. Define the Parent constructor that receives 13 parameters,  and invokes the Grandparents constructor first,
// For the constructors we declare our new private variables, and add the ones from GP tradition.

    public ParentsTradition(String holidayName, String holidaySeason, String timeOfDayCelebration, String mainDishName, int numberOfSideDishes, String locationOfGathering, double costOfMeal, String mealSource, int numberInvited, String traditionalDessert, String traditionalDrink, double costPerDessert, double costPerDrink) {
        // super copy paste the constructors. Do not pass the data types, only put the seven that are common
        // super keyword refrences the variables from our super class GP.
        super (holidayName, holidaySeason, timeOfDayCelebration, mainDishName, numberOfSideDishes, locationOfGathering, costOfMeal, mealSource);
       
        this.numberInvited = numberInvited;
        this.traditionalDessert = traditionalDessert;
        this.traditionalDrink = traditionalDrink;
        this.costPerDessert = costPerDessert;
        this.costPerDrink = costPerDrink;
    }



//3.  and then initializes the rest of the values in the Parents' attributes.

//4. Define a getter and a setter for each of the 5 attributes in the Parent class

    public int nunberInvited() {
        return numberInvited;
    }

    public void setnumberInvited(int numberInvited) {
        this.numberInvited = numberInvited;
    }

    public String gettraditionalDessert() {
        return traditionalDessert;
    }

    public void settraditionalDessert(String traditionalDessert) {
        this.traditionalDessert = traditionalDessert;
    }

    public String gettradtionalDrink() {
        return traditionalDrink;
    }

    public void settraditionalDrink(String traditionalDrink) {
        this.traditionalDrink = traditionalDrink;
    }

    public double getcostPerDessert() {
        return costPerDessert;
    }

    public void setcostPerDessert(double costPerDessert) {
        this.costPerDessert = costPerDessert;
    }

    public double getcostPerDrink() {
        return costPerDrink;
    }

    public void setcostPerDrink(double costPerDrink) {
        this.costPerDrink = costPerDrink;
    }

//5. Define the toString() method invoking the 
//   toString() of the super class PLUS it 
//     concatenates its own toString logic:
//
//  We ALSO like to invite at least __ friends over to our house after our meal to eat _____ for dessert, and drink _____.
//  We pay ____ for each dessert, and ____ for each drink. 
//  
//
    
    @Override
    public String toString() 
    {
        DecimalFormat df = new DecimalFormat("##0.00");

        return super.toString() + "\nWe ALSO like to invite at least " + numberInvited + " friends over to our house after our meal to eat " + traditionalDessert
                + " for dessert, and drink " + traditionalDrink + "\nWe pay $" + df.format(costPerDessert) + " for each dessert, and $"+ df.format(costPerDrink)+ " for each drink "
                ;
    }
    
    //6. Define the POLYMORPHIC celebrate method that concatenates "We parents like to celebrate the holidays like " to the toString
    // We do not a super to celebrate , because if we do, it will have it so there is no difference in the
    // We_____ like to celebrate, itll all be the same.

    @Override
        public String celebrate () 
        {
       
          return "\nWe parents like to celebrate the holidays like " + toString();
        
        }

    //7. Define the POLYMORPHIC tabulateCosts method that concatenates "plus the costs of desserts & drinks per guest: ____"

    @Override
            public String tabulateCosts() 
            {
              DecimalFormat df = new DecimalFormat("##0.00");
              return super.tabulateCosts() + " plus the costs of desserts & drinks per guest: $" + df.format ( costPerDessert + costPerDrink *numberInvited) ;
       
            }












}



     
   
