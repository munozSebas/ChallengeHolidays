/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidaycelebrations;

import java.text.DecimalFormat;

/**
 *
 *
 */

// @author: Sebastian Munoz (6306841)
//2/2/22

// As the Celebratable class is a interface, by implementing it on the Super Class (Parent Class), we do not
// have to implement them again in ChildrenTradition and ParentsTradition

public class GrandparentsTradition implements Celebratable {
    
    
    // Declaration of private String, this will be derived soon in the ParentTradition and ChildrenTradition
    
    private String holidayName;
    private String holidaySeason;
    private String timeOfDayCelebration;      
    private String mainDishName;    
    private int numberOfSideDishes;
    private String locationOfGathering;      
    private double costOfMeal;
    private String mealSource;               

    // This is our constructor, each deriving from our privates we declared.
    public GrandparentsTradition(String holidayName, String holidaySeason, String timeOfDayCelebration, String mainDishName, int numberOfSideDishes, String locationOfGathering, double costOfMeal, String mealSource) {
       // this. is a reference variable that refers to the current object.
        this.holidayName = holidayName;
        this.holidaySeason = holidaySeason;
        this.timeOfDayCelebration = timeOfDayCelebration;
        this.mainDishName = mainDishName;
        this.numberOfSideDishes = numberOfSideDishes;
        this.locationOfGathering = locationOfGathering;
        this.costOfMeal = costOfMeal;
        this.mealSource = mealSource;
    }

    
    // When use inheritance, it is key to use getters and setters based off the constructors.
    public String getHolidayName() {
        return holidayName;
    }

    public void setHolidayName(String holidayName) {
        this.holidayName = holidayName;
    }

    public String getHolidaySeason() {
        return holidaySeason;
    }

    public void setHolidaySeason(String holidaySeason) {
        this.holidaySeason = holidaySeason;
    }

    public String getTimeOfDayCelebration() {
        return timeOfDayCelebration;
    }

    public void setTimeOfDayCelebration(String timeOfDayCelebration) {
        this.timeOfDayCelebration = timeOfDayCelebration;
    }

    public String getMainDishName() {
        return mainDishName;
    }

    public void setMainDishName(String mainDishName) {
        this.mainDishName = mainDishName;
    }

    public int getNumberOfSideDishes() {
        return numberOfSideDishes;
    }

    public void setNumberOfSideDishes(int numberOfSideDishes) {
        this.numberOfSideDishes = numberOfSideDishes;
    }

    public String getLocationOfGathering() {
        return locationOfGathering;
    }

    public void setLocationOfGathering(String locationOfGathering) {
        this.locationOfGathering = locationOfGathering;
    }

    public double getCostPerServing() {
        return costOfMeal;
    }

    public void setCostPerServing(double costOfMeal) {
        this.costOfMeal = costOfMeal;
    }

    public String getMealSource() {
        return mealSource;
    }

    public void setMealSource(String mealSource) {
        this.mealSource = mealSource;
    }

    // These are the toString methods each overriding from the other classes, that have the same method name. As each 
    // display is different.
    
    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("##0.00");
        return holidayName + " during the " +  holidaySeason + " holiday season at the " + 
                timeOfDayCelebration + ".  \nWe eat " + mainDishName + " as the main dish, with " + numberOfSideDishes + " side dishes." 
                + "\nWe like to eat in the " + locationOfGathering + ". \nThe food is from a " + mealSource + " source. \nThe cost per serving is about $" + df.format(costOfMeal) ; 
    
    }
    
    // These methods are from our already implemented interface.
    // They must be used in all classes if an implemented is being used. 
    // Here they work as a return statement that will then be our output
    @Override
     public String celebrate()
    {
        return "\nWe grandparents like to celebrate the holidays like " + toString();
    }
    
     @Override
     public String tabulateCosts()
     {
         DecimalFormat df = new DecimalFormat("##0.00");
         return "For a typical gathering of 10, we will spend " + df.format(costOfMeal * 10);
     }
    
}
