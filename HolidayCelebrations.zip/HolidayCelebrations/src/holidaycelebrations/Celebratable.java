/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidaycelebrations;

/**
 *
 * @author Cristy
 */

//@author: Sebastian Munoz (6306841)
//2/2/22

public interface Celebratable {

    
    
    public String celebrate();
    
    public String tabulateCosts();
            // This is going to be a string because it will add specific info of what cost.
    
}
